﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace TmShuttle
{
    public partial class FrmGlobalConfig : Form
    {
        [DllImport("ASeries.dll")]
        public static extern bool SerialOpen(uint portnr, uint baud, uint parity, uint databits, uint stopbit);

        [DllImport("ASeries.dll")]
        public static extern bool SerialClose();

        [DllImport("ASeries.dll")]
        public static extern uint SerialSend(byte[] data, uint datalen);

        [DllImport("ASeries.dll")]
        public static extern uint SerialRecv(byte[] data, uint datalen);

        [DllImport("ASeries.dll")]
        public static extern bool SerialSetReadTimeOut(uint dwMilliSecond);

        [DllImport("ASeries.dll")]
        public static extern bool Write_A101_RelayBit(byte addr, byte relaybit, byte state);

        [DllImport("ASeries.dll")]
        public static extern bool Write_A101_RelayAll(byte addr, byte state);

        [DllImport("ASeries.dll")]
        public static extern UInt32 Read_A101_RelayAll(byte addr);

        public FrmGlobalConfig()
        {
            InitializeComponent();

            cboSerialNum1.SelectedIndex = (int)(GlobaConfigInstance.Instance[0].SerialNum - 1);
            cboBaudrate1.Text = GlobaConfigInstance.Instance[0].Baud.ToString();
            cboPresentAddr1.Text = GlobaConfigInstance.Instance[0].Addr.ToString();

            cboSerialNum2.SelectedIndex = (int)(GlobaConfigInstance.Instance[1].SerialNum - 1);
            cboBaudrate2.Text = GlobaConfigInstance.Instance[1].Baud.ToString();
            cboPresentAddr2.Text = GlobaConfigInstance.Instance[1].Addr.ToString();

            cboSerialNum3.SelectedIndex = (int)(GlobaConfigInstance.Instance[2].SerialNum - 1);
            cboBaudrate3.Text = GlobaConfigInstance.Instance[2].Baud.ToString();
            cboPresentAddr3.Text = GlobaConfigInstance.Instance[2].Addr.ToString();

            cboSerialNum4.SelectedIndex = (int)(GlobaConfigInstance.Instance[3].SerialNum - 1);
            cboBaudrate4.Text = GlobaConfigInstance.Instance[3].Baud.ToString();
            cboPresentAddr4.Text = GlobaConfigInstance.Instance[3].Addr.ToString();
        }

        private void btnOpenSerial_Click(object sender, EventArgs e)
        {
            OpenSerial(sender as Button, 1);
        }

        private void OpenSerial(Button currentButton, int index)
        {
            if (currentButton.Text == "打开串口")
            {
                try
                {
                    bool state;
                    uint serialnum = Convert.ToUInt32(cboSerialNum1.SelectedIndex + 1);

                    uint baud = Convert.ToUInt32(cboBaudrate1.Text);

                    state = SerialOpen(serialnum, baud, 0, 8, 0);
                    if (state == false)
                    {
                        MessageBox.Show("打开失败！");
                        return;
                    }
                    currentButton.Text = "关闭串口";
                }
                catch
                {
                    MessageBox.Show("打开失败！");
                    return;
                }
            }
            else if (currentButton.Text == "关闭串口")
            {
                try
                {
                    bool state;

                    state = SerialClose();
                    if (state == false)
                    {
                        MessageBox.Show("关闭失败！");
                        return;
                    }
                    else
                    {
                        currentButton.Text = "打开串口";
                    }
                }
                catch
                {
                    MessageBox.Show("关闭失败！");
                    return;
                }
            }
        }

        private void GlobalConfig_Load(object sender, EventArgs e)
        {

        }

        private void FrmGlobalConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            SerialClose();
        }

        private void btn_SaveBox1_Click(object sender, EventArgs e)
        {
            //成功后写入配置文件
            GlobaConfigInstance.Instance[0].Addr = byte.Parse(cboPresentAddr1.SelectedItem.ToString());
            GlobaConfigInstance.Instance[0].SerialNum = Convert.ToUInt32(cboSerialNum1.SelectedIndex + 1);
            GlobaConfigInstance.Instance[0].Baud = Convert.ToUInt32(cboBaudrate1.Text);
            
        }

        private void btnOpenSerial2_Click(object sender, EventArgs e)
        {

        }

        private void btnOpenSerial3_Click(object sender, EventArgs e)
        {

        }

        private void btnOpenSerial4_Click(object sender, EventArgs e)
        {

        }

        private void btn_SaveBox2_Click(object sender, EventArgs e)
        {

        }

        private void btn_SaveBox3_Click(object sender, EventArgs e)
        {

        }

        private void btn_SaveBox4_Click(object sender, EventArgs e)
        {

        }
    }
}

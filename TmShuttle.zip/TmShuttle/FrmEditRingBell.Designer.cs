﻿namespace TmShuttle
{
    partial class FrmEditRingBell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.btnRelay15 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.btnRelay14 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.btnRelay13 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.btnRelay12 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.btnRelay11 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.btnRelay10 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRelay09 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRelay08 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.label3 = new System.Windows.Forms.Label();
            this.btnRelay00 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRelay01 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.label5 = new System.Windows.Forms.Label();
            this.btnRelay02 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.txt_MusicName = new System.Windows.Forms.TextBox();
            this.btnRelay03 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.txt_FileName = new System.Windows.Forms.TextBox();
            this.btnRelay04 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.txt_FilePath = new System.Windows.Forms.TextBox();
            this.btnRelay05 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.btnRelay06 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.dpk_RingTime = new ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker();
            this.btnRelay07 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.btn_Confrm = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.btn_Cancel = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.nud_Duaration = new ComponentFactory.Krypton.Toolkit.KryptonNumericUpDown();
            this.btn_OpenFile = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.pl_ButtonGroup = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonNavigator1 = new ComponentFactory.Krypton.Navigator.KryptonNavigator();
            this.kryptonPage1 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonPage2 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonCheckButton1 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton2 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton3 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton4 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton5 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton6 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton7 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton8 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton9 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton10 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton11 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton12 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton13 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton14 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton15 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton16 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonPage3 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonCheckButton17 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton18 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton19 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton20 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton21 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton22 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton23 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton24 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton25 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton26 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton27 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton28 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton29 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton30 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton31 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton32 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonPage4 = new ComponentFactory.Krypton.Navigator.KryptonPage();
            this.kryptonCheckButton33 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton34 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton35 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton36 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton37 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton38 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton39 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton40 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton41 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton42 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton43 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton44 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton45 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton46 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton47 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            this.kryptonCheckButton48 = new ComponentFactory.Krypton.Toolkit.KryptonCheckButton();
            ((System.ComponentModel.ISupportInitialize)(this.pl_ButtonGroup)).BeginInit();
            this.pl_ButtonGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonNavigator1)).BeginInit();
            this.kryptonNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage1)).BeginInit();
            this.kryptonPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage2)).BeginInit();
            this.kryptonPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage3)).BeginInit();
            this.kryptonPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage4)).BeginInit();
            this.kryptonPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFile
            // 
            this.openFile.FileName = "openFileDialog1";
            this.openFile.Filter = "MP3文件|*.mp3|WAV文件|*.wav";
            // 
            // btnRelay15
            // 
            this.btnRelay15.Location = new System.Drawing.Point(11, 12);
            this.btnRelay15.Name = "btnRelay15";
            this.btnRelay15.Size = new System.Drawing.Size(100, 29);
            this.btnRelay15.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay15.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay15.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay15.TabIndex = 15;
            this.btnRelay15.Tag = "32768";
            this.btnRelay15.Values.Text = "15";
            // 
            // btnRelay14
            // 
            this.btnRelay14.Location = new System.Drawing.Point(121, 12);
            this.btnRelay14.Name = "btnRelay14";
            this.btnRelay14.Size = new System.Drawing.Size(100, 29);
            this.btnRelay14.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay14.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay14.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay14.TabIndex = 14;
            this.btnRelay14.Tag = "16384";
            this.btnRelay14.Values.Text = "14";
            // 
            // btnRelay13
            // 
            this.btnRelay13.Location = new System.Drawing.Point(231, 12);
            this.btnRelay13.Name = "btnRelay13";
            this.btnRelay13.Size = new System.Drawing.Size(100, 29);
            this.btnRelay13.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay13.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay13.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay13.TabIndex = 13;
            this.btnRelay13.Tag = "8192";
            this.btnRelay13.Values.Text = "13";
            // 
            // btnRelay12
            // 
            this.btnRelay12.Location = new System.Drawing.Point(340, 12);
            this.btnRelay12.Name = "btnRelay12";
            this.btnRelay12.Size = new System.Drawing.Size(100, 29);
            this.btnRelay12.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay12.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay12.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay12.TabIndex = 12;
            this.btnRelay12.Tag = "4096";
            this.btnRelay12.Values.Text = "12";
            // 
            // btnRelay11
            // 
            this.btnRelay11.Location = new System.Drawing.Point(11, 68);
            this.btnRelay11.Name = "btnRelay11";
            this.btnRelay11.Size = new System.Drawing.Size(100, 29);
            this.btnRelay11.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay11.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay11.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay11.TabIndex = 11;
            this.btnRelay11.Tag = "2048";
            this.btnRelay11.Values.Text = "11";
            // 
            // btnRelay10
            // 
            this.btnRelay10.Location = new System.Drawing.Point(121, 68);
            this.btnRelay10.Name = "btnRelay10";
            this.btnRelay10.Size = new System.Drawing.Size(100, 29);
            this.btnRelay10.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay10.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay10.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay10.TabIndex = 10;
            this.btnRelay10.Tag = "1024";
            this.btnRelay10.Values.Text = "10";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(16, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "名称";
            // 
            // btnRelay09
            // 
            this.btnRelay09.Location = new System.Drawing.Point(231, 68);
            this.btnRelay09.Name = "btnRelay09";
            this.btnRelay09.Size = new System.Drawing.Size(100, 29);
            this.btnRelay09.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay09.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay09.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay09.TabIndex = 9;
            this.btnRelay09.Tag = "512";
            this.btnRelay09.Values.Text = "9";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(16, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "打铃时间";
            // 
            // btnRelay08
            // 
            this.btnRelay08.Location = new System.Drawing.Point(340, 68);
            this.btnRelay08.Name = "btnRelay08";
            this.btnRelay08.Size = new System.Drawing.Size(100, 29);
            this.btnRelay08.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay08.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay08.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay08.TabIndex = 8;
            this.btnRelay08.Tag = "256";
            this.btnRelay08.Values.Text = "8";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(243, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "时长（分钟）";
            // 
            // btnRelay00
            // 
            this.btnRelay00.Location = new System.Drawing.Point(11, 122);
            this.btnRelay00.Name = "btnRelay00";
            this.btnRelay00.Size = new System.Drawing.Size(100, 29);
            this.btnRelay00.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay00.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay00.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay00.TabIndex = 0;
            this.btnRelay00.Tag = "1";
            this.btnRelay00.Values.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(16, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "播放曲目名称";
            // 
            // btnRelay01
            // 
            this.btnRelay01.Location = new System.Drawing.Point(121, 122);
            this.btnRelay01.Name = "btnRelay01";
            this.btnRelay01.Size = new System.Drawing.Size(100, 29);
            this.btnRelay01.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay01.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay01.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay01.TabIndex = 1;
            this.btnRelay01.Tag = "2";
            this.btnRelay01.Values.Text = "1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(16, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "铃声路径";
            // 
            // btnRelay02
            // 
            this.btnRelay02.Location = new System.Drawing.Point(231, 122);
            this.btnRelay02.Name = "btnRelay02";
            this.btnRelay02.Size = new System.Drawing.Size(100, 29);
            this.btnRelay02.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay02.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay02.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay02.TabIndex = 2;
            this.btnRelay02.Tag = "4";
            this.btnRelay02.Values.Text = "2";
            // 
            // txt_MusicName
            // 
            this.txt_MusicName.Location = new System.Drawing.Point(119, 10);
            this.txt_MusicName.Name = "txt_MusicName";
            this.txt_MusicName.Size = new System.Drawing.Size(323, 21);
            this.txt_MusicName.TabIndex = 5;
            // 
            // btnRelay03
            // 
            this.btnRelay03.Location = new System.Drawing.Point(340, 122);
            this.btnRelay03.Name = "btnRelay03";
            this.btnRelay03.Size = new System.Drawing.Size(100, 29);
            this.btnRelay03.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay03.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay03.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay03.TabIndex = 3;
            this.btnRelay03.Tag = "8";
            this.btnRelay03.Values.Text = "3";
            // 
            // txt_FileName
            // 
            this.txt_FileName.Location = new System.Drawing.Point(119, 66);
            this.txt_FileName.Name = "txt_FileName";
            this.txt_FileName.ReadOnly = true;
            this.txt_FileName.Size = new System.Drawing.Size(323, 21);
            this.txt_FileName.TabIndex = 8;
            // 
            // btnRelay04
            // 
            this.btnRelay04.Location = new System.Drawing.Point(11, 175);
            this.btnRelay04.Name = "btnRelay04";
            this.btnRelay04.Size = new System.Drawing.Size(100, 29);
            this.btnRelay04.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay04.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay04.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay04.TabIndex = 4;
            this.btnRelay04.Tag = "16";
            this.btnRelay04.Values.Text = "4";
            // 
            // txt_FilePath
            // 
            this.txt_FilePath.Location = new System.Drawing.Point(119, 93);
            this.txt_FilePath.Name = "txt_FilePath";
            this.txt_FilePath.ReadOnly = true;
            this.txt_FilePath.Size = new System.Drawing.Size(271, 21);
            this.txt_FilePath.TabIndex = 9;
            // 
            // btnRelay05
            // 
            this.btnRelay05.Location = new System.Drawing.Point(121, 175);
            this.btnRelay05.Name = "btnRelay05";
            this.btnRelay05.Size = new System.Drawing.Size(100, 29);
            this.btnRelay05.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay05.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay05.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay05.TabIndex = 5;
            this.btnRelay05.Tag = "32";
            this.btnRelay05.Values.Text = "5";
            // 
            // btnRelay06
            // 
            this.btnRelay06.Location = new System.Drawing.Point(231, 175);
            this.btnRelay06.Name = "btnRelay06";
            this.btnRelay06.Size = new System.Drawing.Size(100, 29);
            this.btnRelay06.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay06.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay06.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay06.TabIndex = 6;
            this.btnRelay06.Tag = "64";
            this.btnRelay06.Values.Text = "6";
            // 
            // dpk_RingTime
            // 
            this.dpk_RingTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dpk_RingTime.Location = new System.Drawing.Point(119, 37);
            this.dpk_RingTime.Name = "dpk_RingTime";
            this.dpk_RingTime.ShowUpDown = true;
            this.dpk_RingTime.Size = new System.Drawing.Size(116, 20);
            this.dpk_RingTime.TabIndex = 11;
            // 
            // btnRelay07
            // 
            this.btnRelay07.Location = new System.Drawing.Point(340, 175);
            this.btnRelay07.Name = "btnRelay07";
            this.btnRelay07.Size = new System.Drawing.Size(100, 29);
            this.btnRelay07.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay07.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnRelay07.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.btnRelay07.StateTracking.Back.Color2 = System.Drawing.Color.Gold;
            this.btnRelay07.TabIndex = 7;
            this.btnRelay07.Tag = "128";
            this.btnRelay07.Values.Text = "7";
            // 
            // btn_Confrm
            // 
            this.btn_Confrm.Location = new System.Drawing.Point(133, 369);
            this.btn_Confrm.Name = "btn_Confrm";
            this.btn_Confrm.Size = new System.Drawing.Size(90, 25);
            this.btn_Confrm.TabIndex = 140;
            this.btn_Confrm.Values.Text = "确定";
            this.btn_Confrm.Click += new System.EventHandler(this.btn_Confrm_Click);
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(235, 369);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(90, 25);
            this.btn_Cancel.TabIndex = 141;
            this.btn_Cancel.Values.Text = "取消";
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // nud_Duaration
            // 
            this.nud_Duaration.Location = new System.Drawing.Point(327, 37);
            this.nud_Duaration.Name = "nud_Duaration";
            this.nud_Duaration.Size = new System.Drawing.Size(115, 20);
            this.nud_Duaration.TabIndex = 142;
            // 
            // btn_OpenFile
            // 
            this.btn_OpenFile.Location = new System.Drawing.Point(397, 92);
            this.btn_OpenFile.Name = "btn_OpenFile";
            this.btn_OpenFile.Size = new System.Drawing.Size(45, 25);
            this.btn_OpenFile.TabIndex = 143;
            this.btn_OpenFile.Values.ExtraText = "打开";
            this.btn_OpenFile.Values.Text = "";
            this.btn_OpenFile.Click += new System.EventHandler(this.btn_OpenFile_Click);
            // 
            // pl_ButtonGroup
            // 
            this.pl_ButtonGroup.Controls.Add(this.kryptonNavigator1);
            this.pl_ButtonGroup.Controls.Add(this.btn_OpenFile);
            this.pl_ButtonGroup.Controls.Add(this.nud_Duaration);
            this.pl_ButtonGroup.Controls.Add(this.btn_Cancel);
            this.pl_ButtonGroup.Controls.Add(this.dpk_RingTime);
            this.pl_ButtonGroup.Controls.Add(this.btn_Confrm);
            this.pl_ButtonGroup.Controls.Add(this.txt_FilePath);
            this.pl_ButtonGroup.Controls.Add(this.txt_FileName);
            this.pl_ButtonGroup.Controls.Add(this.txt_MusicName);
            this.pl_ButtonGroup.Controls.Add(this.label5);
            this.pl_ButtonGroup.Controls.Add(this.label4);
            this.pl_ButtonGroup.Controls.Add(this.label3);
            this.pl_ButtonGroup.Controls.Add(this.label2);
            this.pl_ButtonGroup.Controls.Add(this.label1);
            this.pl_ButtonGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pl_ButtonGroup.Location = new System.Drawing.Point(0, 0);
            this.pl_ButtonGroup.Name = "pl_ButtonGroup";
            this.pl_ButtonGroup.Size = new System.Drawing.Size(460, 402);
            this.pl_ButtonGroup.TabIndex = 77;
            // 
            // kryptonNavigator1
            // 
            this.kryptonNavigator1.Button.CloseButtonDisplay = ComponentFactory.Krypton.Navigator.ButtonDisplay.Hide;
            this.kryptonNavigator1.Button.ContextButtonDisplay = ComponentFactory.Krypton.Navigator.ButtonDisplay.Hide;
            this.kryptonNavigator1.Group.GroupBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.ControlClient;
            this.kryptonNavigator1.Group.GroupBorderStyle = ComponentFactory.Krypton.Toolkit.PaletteBorderStyle.ControlClient;
            this.kryptonNavigator1.Location = new System.Drawing.Point(3, 123);
            this.kryptonNavigator1.Name = "kryptonNavigator1";
            this.kryptonNavigator1.Pages.AddRange(new ComponentFactory.Krypton.Navigator.KryptonPage[] {
            this.kryptonPage1,
            this.kryptonPage2,
            this.kryptonPage3,
            this.kryptonPage4});
            this.kryptonNavigator1.SelectedIndex = 0;
            this.kryptonNavigator1.Size = new System.Drawing.Size(457, 241);
            this.kryptonNavigator1.TabIndex = 144;
            this.kryptonNavigator1.Text = "kryptonNavigator1";
            // 
            // kryptonPage1
            // 
            this.kryptonPage1.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage1.Controls.Add(this.btnRelay15);
            this.kryptonPage1.Controls.Add(this.btnRelay14);
            this.kryptonPage1.Controls.Add(this.btnRelay13);
            this.kryptonPage1.Controls.Add(this.btnRelay12);
            this.kryptonPage1.Controls.Add(this.btnRelay11);
            this.kryptonPage1.Controls.Add(this.btnRelay07);
            this.kryptonPage1.Controls.Add(this.btnRelay10);
            this.kryptonPage1.Controls.Add(this.btnRelay09);
            this.kryptonPage1.Controls.Add(this.btnRelay06);
            this.kryptonPage1.Controls.Add(this.btnRelay08);
            this.kryptonPage1.Controls.Add(this.btnRelay05);
            this.kryptonPage1.Controls.Add(this.btnRelay00);
            this.kryptonPage1.Controls.Add(this.btnRelay01);
            this.kryptonPage1.Controls.Add(this.btnRelay04);
            this.kryptonPage1.Controls.Add(this.btnRelay02);
            this.kryptonPage1.Controls.Add(this.btnRelay03);
            this.kryptonPage1.Flags = 65534;
            this.kryptonPage1.LastVisibleSet = true;
            this.kryptonPage1.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage1.Name = "kryptonPage1";
            this.kryptonPage1.Size = new System.Drawing.Size(455, 216);
            this.kryptonPage1.Text = "主机1";
            this.kryptonPage1.ToolTipTitle = "Page ToolTip";
            this.kryptonPage1.UniqueName = "30626630B54640932A8E91E02CC8394E";
            // 
            // kryptonPage2
            // 
            this.kryptonPage2.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton1);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton2);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton3);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton4);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton5);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton6);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton7);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton8);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton9);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton10);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton11);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton12);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton13);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton14);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton15);
            this.kryptonPage2.Controls.Add(this.kryptonCheckButton16);
            this.kryptonPage2.Flags = 65534;
            this.kryptonPage2.LastVisibleSet = true;
            this.kryptonPage2.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage2.Name = "kryptonPage2";
            this.kryptonPage2.Size = new System.Drawing.Size(455, 216);
            this.kryptonPage2.Tag = "";
            this.kryptonPage2.Text = "主机2";
            this.kryptonPage2.ToolTipTitle = "Page ToolTip";
            this.kryptonPage2.UniqueName = "4986CE86AF05446E4EB5C5724042FA8B";
            // 
            // kryptonCheckButton1
            // 
            this.kryptonCheckButton1.Location = new System.Drawing.Point(13, 11);
            this.kryptonCheckButton1.Name = "kryptonCheckButton1";
            this.kryptonCheckButton1.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton1.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton1.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton1.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton1.TabIndex = 15;
            this.kryptonCheckButton1.Tag = "32768";
            this.kryptonCheckButton1.Values.Text = "15";
            // 
            // kryptonCheckButton2
            // 
            this.kryptonCheckButton2.Location = new System.Drawing.Point(123, 11);
            this.kryptonCheckButton2.Name = "kryptonCheckButton2";
            this.kryptonCheckButton2.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton2.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton2.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton2.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton2.TabIndex = 14;
            this.kryptonCheckButton2.Tag = "16384";
            this.kryptonCheckButton2.Values.Text = "14";
            // 
            // kryptonCheckButton3
            // 
            this.kryptonCheckButton3.Location = new System.Drawing.Point(233, 11);
            this.kryptonCheckButton3.Name = "kryptonCheckButton3";
            this.kryptonCheckButton3.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton3.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton3.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton3.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton3.TabIndex = 13;
            this.kryptonCheckButton3.Tag = "8192";
            this.kryptonCheckButton3.Values.Text = "13";
            // 
            // kryptonCheckButton4
            // 
            this.kryptonCheckButton4.Location = new System.Drawing.Point(342, 11);
            this.kryptonCheckButton4.Name = "kryptonCheckButton4";
            this.kryptonCheckButton4.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton4.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton4.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton4.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton4.TabIndex = 12;
            this.kryptonCheckButton4.Tag = "4096";
            this.kryptonCheckButton4.Values.Text = "12";
            // 
            // kryptonCheckButton5
            // 
            this.kryptonCheckButton5.Location = new System.Drawing.Point(13, 67);
            this.kryptonCheckButton5.Name = "kryptonCheckButton5";
            this.kryptonCheckButton5.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton5.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton5.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton5.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton5.TabIndex = 13;
            this.kryptonCheckButton5.Tag = "2048";
            this.kryptonCheckButton5.Values.Text = "11";
            // 
            // kryptonCheckButton6
            // 
            this.kryptonCheckButton6.Location = new System.Drawing.Point(342, 174);
            this.kryptonCheckButton6.Name = "kryptonCheckButton6";
            this.kryptonCheckButton6.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton6.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton6.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton6.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton6.StateTracking.Back.Color2 = System.Drawing.Color.Gold;
            this.kryptonCheckButton6.TabIndex = 7;
            this.kryptonCheckButton6.Tag = "128";
            this.kryptonCheckButton6.Values.Text = "7";
            // 
            // kryptonCheckButton7
            // 
            this.kryptonCheckButton7.Location = new System.Drawing.Point(123, 67);
            this.kryptonCheckButton7.Name = "kryptonCheckButton7";
            this.kryptonCheckButton7.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton7.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton7.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton7.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton7.TabIndex = 10;
            this.kryptonCheckButton7.Tag = "1024";
            this.kryptonCheckButton7.Values.Text = "10";
            // 
            // kryptonCheckButton8
            // 
            this.kryptonCheckButton8.Location = new System.Drawing.Point(233, 67);
            this.kryptonCheckButton8.Name = "kryptonCheckButton8";
            this.kryptonCheckButton8.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton8.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton8.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton8.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton8.TabIndex = 9;
            this.kryptonCheckButton8.Tag = "512";
            this.kryptonCheckButton8.Values.Text = "9";
            // 
            // kryptonCheckButton9
            // 
            this.kryptonCheckButton9.Location = new System.Drawing.Point(233, 174);
            this.kryptonCheckButton9.Name = "kryptonCheckButton9";
            this.kryptonCheckButton9.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton9.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton9.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton9.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton9.TabIndex = 6;
            this.kryptonCheckButton9.Tag = "64";
            this.kryptonCheckButton9.Values.Text = "6";
            // 
            // kryptonCheckButton10
            // 
            this.kryptonCheckButton10.Location = new System.Drawing.Point(342, 67);
            this.kryptonCheckButton10.Name = "kryptonCheckButton10";
            this.kryptonCheckButton10.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton10.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton10.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton10.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton10.TabIndex = 8;
            this.kryptonCheckButton10.Tag = "256";
            this.kryptonCheckButton10.Values.Text = "8";
            // 
            // kryptonCheckButton11
            // 
            this.kryptonCheckButton11.Location = new System.Drawing.Point(123, 174);
            this.kryptonCheckButton11.Name = "kryptonCheckButton11";
            this.kryptonCheckButton11.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton11.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton11.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton11.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton11.TabIndex = 5;
            this.kryptonCheckButton11.Tag = "32";
            this.kryptonCheckButton11.Values.Text = "5";
            // 
            // kryptonCheckButton12
            // 
            this.kryptonCheckButton12.Location = new System.Drawing.Point(13, 121);
            this.kryptonCheckButton12.Name = "kryptonCheckButton12";
            this.kryptonCheckButton12.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton12.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton12.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton12.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton12.TabIndex = 0;
            this.kryptonCheckButton12.Tag = "1";
            this.kryptonCheckButton12.Values.Text = "0";
            // 
            // kryptonCheckButton13
            // 
            this.kryptonCheckButton13.Location = new System.Drawing.Point(123, 121);
            this.kryptonCheckButton13.Name = "kryptonCheckButton13";
            this.kryptonCheckButton13.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton13.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton13.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton13.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton13.TabIndex = 1;
            this.kryptonCheckButton13.Tag = "2";
            this.kryptonCheckButton13.Values.Text = "1";
            // 
            // kryptonCheckButton14
            // 
            this.kryptonCheckButton14.Location = new System.Drawing.Point(13, 174);
            this.kryptonCheckButton14.Name = "kryptonCheckButton14";
            this.kryptonCheckButton14.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton14.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton14.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton14.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton14.TabIndex = 4;
            this.kryptonCheckButton14.Tag = "16";
            this.kryptonCheckButton14.Values.Text = "4";
            // 
            // kryptonCheckButton15
            // 
            this.kryptonCheckButton15.Location = new System.Drawing.Point(233, 121);
            this.kryptonCheckButton15.Name = "kryptonCheckButton15";
            this.kryptonCheckButton15.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton15.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton15.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton15.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton15.TabIndex = 2;
            this.kryptonCheckButton15.Tag = "4";
            this.kryptonCheckButton15.Values.Text = "2";
            // 
            // kryptonCheckButton16
            // 
            this.kryptonCheckButton16.Location = new System.Drawing.Point(342, 121);
            this.kryptonCheckButton16.Name = "kryptonCheckButton16";
            this.kryptonCheckButton16.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton16.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton16.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton16.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton16.TabIndex = 3;
            this.kryptonCheckButton16.Tag = "8";
            this.kryptonCheckButton16.Values.Text = "3";
            // 
            // kryptonPage3
            // 
            this.kryptonPage3.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton17);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton18);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton19);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton20);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton21);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton22);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton23);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton24);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton25);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton26);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton27);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton28);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton29);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton30);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton31);
            this.kryptonPage3.Controls.Add(this.kryptonCheckButton32);
            this.kryptonPage3.Flags = 65534;
            this.kryptonPage3.LastVisibleSet = true;
            this.kryptonPage3.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage3.Name = "kryptonPage3";
            this.kryptonPage3.Size = new System.Drawing.Size(455, 216);
            this.kryptonPage3.Tag = "";
            this.kryptonPage3.Text = "主机3";
            this.kryptonPage3.ToolTipTitle = "Page ToolTip";
            this.kryptonPage3.UniqueName = "CC7D6AF0D56548EF22B42074C77E41AA";
            // 
            // kryptonCheckButton17
            // 
            this.kryptonCheckButton17.Location = new System.Drawing.Point(13, 11);
            this.kryptonCheckButton17.Name = "kryptonCheckButton17";
            this.kryptonCheckButton17.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton17.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton17.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton17.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton17.TabIndex = 15;
            this.kryptonCheckButton17.Tag = "32768";
            this.kryptonCheckButton17.Values.Text = "15";
            // 
            // kryptonCheckButton18
            // 
            this.kryptonCheckButton18.Location = new System.Drawing.Point(123, 11);
            this.kryptonCheckButton18.Name = "kryptonCheckButton18";
            this.kryptonCheckButton18.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton18.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton18.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton18.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton18.TabIndex = 14;
            this.kryptonCheckButton18.Tag = "16384";
            this.kryptonCheckButton18.Values.Text = "14";
            // 
            // kryptonCheckButton19
            // 
            this.kryptonCheckButton19.Location = new System.Drawing.Point(233, 11);
            this.kryptonCheckButton19.Name = "kryptonCheckButton19";
            this.kryptonCheckButton19.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton19.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton19.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton19.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton19.TabIndex = 13;
            this.kryptonCheckButton19.Tag = "8192";
            this.kryptonCheckButton19.Values.Text = "13";
            // 
            // kryptonCheckButton20
            // 
            this.kryptonCheckButton20.Location = new System.Drawing.Point(342, 11);
            this.kryptonCheckButton20.Name = "kryptonCheckButton20";
            this.kryptonCheckButton20.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton20.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton20.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton20.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton20.TabIndex = 12;
            this.kryptonCheckButton20.Tag = "4096";
            this.kryptonCheckButton20.Values.Text = "12";
            // 
            // kryptonCheckButton21
            // 
            this.kryptonCheckButton21.Location = new System.Drawing.Point(13, 67);
            this.kryptonCheckButton21.Name = "kryptonCheckButton21";
            this.kryptonCheckButton21.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton21.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton21.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton21.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton21.TabIndex = 11;
            this.kryptonCheckButton21.Tag = "2048";
            this.kryptonCheckButton21.Values.Text = "11";
            // 
            // kryptonCheckButton22
            // 
            this.kryptonCheckButton22.Location = new System.Drawing.Point(342, 174);
            this.kryptonCheckButton22.Name = "kryptonCheckButton22";
            this.kryptonCheckButton22.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton22.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton22.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton22.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton22.StateTracking.Back.Color2 = System.Drawing.Color.Gold;
            this.kryptonCheckButton22.TabIndex = 7;
            this.kryptonCheckButton22.Tag = "128";
            this.kryptonCheckButton22.Values.Text = "7";
            // 
            // kryptonCheckButton23
            // 
            this.kryptonCheckButton23.Location = new System.Drawing.Point(123, 67);
            this.kryptonCheckButton23.Name = "kryptonCheckButton23";
            this.kryptonCheckButton23.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton23.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton23.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton23.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton23.TabIndex = 10;
            this.kryptonCheckButton23.Tag = "1024";
            this.kryptonCheckButton23.Values.Text = "10";
            // 
            // kryptonCheckButton24
            // 
            this.kryptonCheckButton24.Location = new System.Drawing.Point(233, 67);
            this.kryptonCheckButton24.Name = "kryptonCheckButton24";
            this.kryptonCheckButton24.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton24.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton24.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton24.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton24.TabIndex = 9;
            this.kryptonCheckButton24.Tag = "512";
            this.kryptonCheckButton24.Values.Text = "9";
            // 
            // kryptonCheckButton25
            // 
            this.kryptonCheckButton25.Location = new System.Drawing.Point(233, 174);
            this.kryptonCheckButton25.Name = "kryptonCheckButton25";
            this.kryptonCheckButton25.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton25.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton25.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton25.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton25.TabIndex = 6;
            this.kryptonCheckButton25.Tag = "64";
            this.kryptonCheckButton25.Values.Text = "6";
            // 
            // kryptonCheckButton26
            // 
            this.kryptonCheckButton26.Location = new System.Drawing.Point(342, 67);
            this.kryptonCheckButton26.Name = "kryptonCheckButton26";
            this.kryptonCheckButton26.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton26.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton26.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton26.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton26.TabIndex = 8;
            this.kryptonCheckButton26.Tag = "256";
            this.kryptonCheckButton26.Values.Text = "8";
            // 
            // kryptonCheckButton27
            // 
            this.kryptonCheckButton27.Location = new System.Drawing.Point(123, 174);
            this.kryptonCheckButton27.Name = "kryptonCheckButton27";
            this.kryptonCheckButton27.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton27.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton27.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton27.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton27.TabIndex = 5;
            this.kryptonCheckButton27.Tag = "32";
            this.kryptonCheckButton27.Values.Text = "5";
            // 
            // kryptonCheckButton28
            // 
            this.kryptonCheckButton28.Location = new System.Drawing.Point(13, 121);
            this.kryptonCheckButton28.Name = "kryptonCheckButton28";
            this.kryptonCheckButton28.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton28.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton28.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton28.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton28.TabIndex = 0;
            this.kryptonCheckButton28.Tag = "1";
            this.kryptonCheckButton28.Values.Text = "0";
            // 
            // kryptonCheckButton29
            // 
            this.kryptonCheckButton29.Location = new System.Drawing.Point(123, 121);
            this.kryptonCheckButton29.Name = "kryptonCheckButton29";
            this.kryptonCheckButton29.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton29.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton29.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton29.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton29.TabIndex = 1;
            this.kryptonCheckButton29.Tag = "2";
            this.kryptonCheckButton29.Values.Text = "1";
            // 
            // kryptonCheckButton30
            // 
            this.kryptonCheckButton30.Location = new System.Drawing.Point(13, 174);
            this.kryptonCheckButton30.Name = "kryptonCheckButton30";
            this.kryptonCheckButton30.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton30.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton30.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton30.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton30.TabIndex = 4;
            this.kryptonCheckButton30.Tag = "16";
            this.kryptonCheckButton30.Values.Text = "4";
            // 
            // kryptonCheckButton31
            // 
            this.kryptonCheckButton31.Location = new System.Drawing.Point(233, 121);
            this.kryptonCheckButton31.Name = "kryptonCheckButton31";
            this.kryptonCheckButton31.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton31.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton31.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton31.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton31.TabIndex = 2;
            this.kryptonCheckButton31.Tag = "4";
            this.kryptonCheckButton31.Values.Text = "2";
            // 
            // kryptonCheckButton32
            // 
            this.kryptonCheckButton32.Location = new System.Drawing.Point(342, 121);
            this.kryptonCheckButton32.Name = "kryptonCheckButton32";
            this.kryptonCheckButton32.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton32.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton32.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton32.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton32.TabIndex = 3;
            this.kryptonCheckButton32.Tag = "8";
            this.kryptonCheckButton32.Values.Text = "3";
            // 
            // kryptonPage4
            // 
            this.kryptonPage4.AutoHiddenSlideSize = new System.Drawing.Size(200, 200);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton33);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton34);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton35);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton36);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton37);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton38);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton39);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton40);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton41);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton42);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton43);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton44);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton45);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton46);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton47);
            this.kryptonPage4.Controls.Add(this.kryptonCheckButton48);
            this.kryptonPage4.Flags = 65534;
            this.kryptonPage4.LastVisibleSet = true;
            this.kryptonPage4.MinimumSize = new System.Drawing.Size(50, 50);
            this.kryptonPage4.Name = "kryptonPage4";
            this.kryptonPage4.Size = new System.Drawing.Size(455, 216);
            this.kryptonPage4.Tag = "";
            this.kryptonPage4.Text = "主机4";
            this.kryptonPage4.ToolTipTitle = "Page ToolTip";
            this.kryptonPage4.UniqueName = "22428058A8EA407C3FB46BD87D9BAFB2";
            // 
            // kryptonCheckButton33
            // 
            this.kryptonCheckButton33.Location = new System.Drawing.Point(13, 11);
            this.kryptonCheckButton33.Name = "kryptonCheckButton33";
            this.kryptonCheckButton33.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton33.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton33.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton33.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton33.TabIndex = 15;
            this.kryptonCheckButton33.Tag = "32768";
            this.kryptonCheckButton33.Values.Text = "15";
            // 
            // kryptonCheckButton34
            // 
            this.kryptonCheckButton34.Location = new System.Drawing.Point(123, 11);
            this.kryptonCheckButton34.Name = "kryptonCheckButton34";
            this.kryptonCheckButton34.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton34.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton34.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton34.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton34.TabIndex = 14;
            this.kryptonCheckButton34.Tag = "16384";
            this.kryptonCheckButton34.Values.Text = "14";
            // 
            // kryptonCheckButton35
            // 
            this.kryptonCheckButton35.Location = new System.Drawing.Point(233, 11);
            this.kryptonCheckButton35.Name = "kryptonCheckButton35";
            this.kryptonCheckButton35.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton35.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton35.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton35.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton35.TabIndex = 13;
            this.kryptonCheckButton35.Tag = "8192";
            this.kryptonCheckButton35.Values.Text = "13";
            // 
            // kryptonCheckButton36
            // 
            this.kryptonCheckButton36.Location = new System.Drawing.Point(342, 11);
            this.kryptonCheckButton36.Name = "kryptonCheckButton36";
            this.kryptonCheckButton36.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton36.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton36.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton36.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton36.TabIndex = 12;
            this.kryptonCheckButton36.Tag = "4096";
            this.kryptonCheckButton36.Values.Text = "12";
            // 
            // kryptonCheckButton37
            // 
            this.kryptonCheckButton37.Location = new System.Drawing.Point(13, 67);
            this.kryptonCheckButton37.Name = "kryptonCheckButton37";
            this.kryptonCheckButton37.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton37.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton37.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton37.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton37.TabIndex = 11;
            this.kryptonCheckButton37.Tag = "2048";
            this.kryptonCheckButton37.Values.Text = "11";
            // 
            // kryptonCheckButton38
            // 
            this.kryptonCheckButton38.Location = new System.Drawing.Point(342, 174);
            this.kryptonCheckButton38.Name = "kryptonCheckButton38";
            this.kryptonCheckButton38.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton38.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton38.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton38.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton38.StateTracking.Back.Color2 = System.Drawing.Color.Gold;
            this.kryptonCheckButton38.TabIndex = 7;
            this.kryptonCheckButton38.Tag = "128";
            this.kryptonCheckButton38.Values.Text = "7";
            // 
            // kryptonCheckButton39
            // 
            this.kryptonCheckButton39.Location = new System.Drawing.Point(123, 67);
            this.kryptonCheckButton39.Name = "kryptonCheckButton39";
            this.kryptonCheckButton39.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton39.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton39.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton39.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton39.TabIndex = 10;
            this.kryptonCheckButton39.Tag = "1024";
            this.kryptonCheckButton39.Values.Text = "10";
            // 
            // kryptonCheckButton40
            // 
            this.kryptonCheckButton40.Location = new System.Drawing.Point(233, 67);
            this.kryptonCheckButton40.Name = "kryptonCheckButton40";
            this.kryptonCheckButton40.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton40.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton40.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton40.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton40.TabIndex = 9;
            this.kryptonCheckButton40.Tag = "512";
            this.kryptonCheckButton40.Values.Text = "9";
            // 
            // kryptonCheckButton41
            // 
            this.kryptonCheckButton41.Location = new System.Drawing.Point(233, 174);
            this.kryptonCheckButton41.Name = "kryptonCheckButton41";
            this.kryptonCheckButton41.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton41.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton41.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton41.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton41.TabIndex = 6;
            this.kryptonCheckButton41.Tag = "64";
            this.kryptonCheckButton41.Values.Text = "6";
            // 
            // kryptonCheckButton42
            // 
            this.kryptonCheckButton42.Location = new System.Drawing.Point(342, 67);
            this.kryptonCheckButton42.Name = "kryptonCheckButton42";
            this.kryptonCheckButton42.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton42.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton42.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton42.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton42.TabIndex = 8;
            this.kryptonCheckButton42.Tag = "256";
            this.kryptonCheckButton42.Values.Text = "8";
            // 
            // kryptonCheckButton43
            // 
            this.kryptonCheckButton43.Location = new System.Drawing.Point(123, 174);
            this.kryptonCheckButton43.Name = "kryptonCheckButton43";
            this.kryptonCheckButton43.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton43.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton43.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton43.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton43.TabIndex = 5;
            this.kryptonCheckButton43.Tag = "32";
            this.kryptonCheckButton43.Values.Text = "5";
            // 
            // kryptonCheckButton44
            // 
            this.kryptonCheckButton44.Location = new System.Drawing.Point(13, 121);
            this.kryptonCheckButton44.Name = "kryptonCheckButton44";
            this.kryptonCheckButton44.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton44.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton44.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton44.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton44.TabIndex = 0;
            this.kryptonCheckButton44.Tag = "1";
            this.kryptonCheckButton44.Values.Text = "0";
            // 
            // kryptonCheckButton45
            // 
            this.kryptonCheckButton45.Location = new System.Drawing.Point(123, 121);
            this.kryptonCheckButton45.Name = "kryptonCheckButton45";
            this.kryptonCheckButton45.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton45.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton45.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton45.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton45.TabIndex = 1;
            this.kryptonCheckButton45.Tag = "2";
            this.kryptonCheckButton45.Values.Text = "1";
            // 
            // kryptonCheckButton46
            // 
            this.kryptonCheckButton46.Location = new System.Drawing.Point(13, 174);
            this.kryptonCheckButton46.Name = "kryptonCheckButton46";
            this.kryptonCheckButton46.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton46.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton46.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton46.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton46.TabIndex = 4;
            this.kryptonCheckButton46.Tag = "16";
            this.kryptonCheckButton46.Values.Text = "4";
            // 
            // kryptonCheckButton47
            // 
            this.kryptonCheckButton47.Location = new System.Drawing.Point(233, 121);
            this.kryptonCheckButton47.Name = "kryptonCheckButton47";
            this.kryptonCheckButton47.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton47.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton47.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton47.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton47.TabIndex = 2;
            this.kryptonCheckButton47.Tag = "4";
            this.kryptonCheckButton47.Values.Text = "2";
            // 
            // kryptonCheckButton48
            // 
            this.kryptonCheckButton48.Location = new System.Drawing.Point(342, 121);
            this.kryptonCheckButton48.Name = "kryptonCheckButton48";
            this.kryptonCheckButton48.Size = new System.Drawing.Size(100, 29);
            this.kryptonCheckButton48.StateCheckedNormal.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton48.StateCheckedPressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kryptonCheckButton48.StateCheckedTracking.Back.Color1 = System.Drawing.Color.Red;
            this.kryptonCheckButton48.TabIndex = 3;
            this.kryptonCheckButton48.Tag = "8";
            this.kryptonCheckButton48.Values.Text = "3";
            // 
            // FrmEditRingBell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 402);
            this.Controls.Add(this.pl_ButtonGroup);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "FrmEditRingBell";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "编辑打铃设置";
            this.Load += new System.EventHandler(this.FrmEditRingBell_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pl_ButtonGroup)).EndInit();
            this.pl_ButtonGroup.ResumeLayout(false);
            this.pl_ButtonGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonNavigator1)).EndInit();
            this.kryptonNavigator1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage1)).EndInit();
            this.kryptonPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage2)).EndInit();
            this.kryptonPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage3)).EndInit();
            this.kryptonPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPage4)).EndInit();
            this.kryptonPage4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_SystemCaption;
        private System.Windows.Forms.OpenFileDialog openFile;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay15;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay14;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay13;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay12;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay11;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay10;
        private System.Windows.Forms.Label label1;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay09;
        private System.Windows.Forms.Label label2;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay08;
        private System.Windows.Forms.Label label3;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay00;
        private System.Windows.Forms.Label label4;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay01;
        private System.Windows.Forms.Label label5;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay02;
        private System.Windows.Forms.TextBox txt_MusicName;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay03;
        private System.Windows.Forms.TextBox txt_FileName;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay04;
        private System.Windows.Forms.TextBox txt_FilePath;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay05;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay06;
        private ComponentFactory.Krypton.Toolkit.KryptonDateTimePicker dpk_RingTime;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton btnRelay07;
        private ComponentFactory.Krypton.Toolkit.KryptonButton btn_Confrm;
        private ComponentFactory.Krypton.Toolkit.KryptonButton btn_Cancel;
        private ComponentFactory.Krypton.Toolkit.KryptonNumericUpDown nud_Duaration;
        private ComponentFactory.Krypton.Toolkit.KryptonButton btn_OpenFile;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel pl_ButtonGroup;
        private ComponentFactory.Krypton.Navigator.KryptonNavigator kryptonNavigator1;
        private ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage1;
        private ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage2;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton1;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton2;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton3;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton4;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton5;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton6;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton7;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton8;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton9;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton10;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton11;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton12;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton13;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton14;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton15;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton16;
        private ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage3;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton17;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton18;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton19;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton20;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton21;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton22;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton23;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton24;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton25;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton26;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton27;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton28;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton29;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton30;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton31;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton32;
        private ComponentFactory.Krypton.Navigator.KryptonPage kryptonPage4;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton33;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton34;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton35;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton36;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton37;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton38;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton39;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton40;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton41;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton42;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton43;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton44;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton45;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton46;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton47;
        private ComponentFactory.Krypton.Toolkit.KryptonCheckButton kryptonCheckButton48;
    }
}